package me.itwl.apiservice;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApiServiceApplicationTests {
    @Test
    public void contextLoads() {
        while (true) ;
    }
}
