package me.itwl.gatewayservice.constant;

public class AuthConstant {

    public static final String AUTHORITY_PREFIX = "ROLE_";

    public static final String AUTHORITY_CLAIM_NAME = "authorities";

}
